package com.crm.demo;

import lombok.Data;

@Data
public class RegisterRequest {
    private String name;
    private String email;
    private String password;
    private Role role; // You could also hardcode a default role in the service instead!
}